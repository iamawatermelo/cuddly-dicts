"""
Turn a KDL document into a dict, following a set of very simple rules.
"""

from collections import OrderedDict
from typing import Collection, Any
import kdl

class KDLTransformException(Exception):
    pass

def _nodes_to_dict(node_list: Collection[kdl.Node], root_name: str) -> dict[str, Any]:
    ret = {}
    
    for node in node_list:
        if node.tag is not None:
            raise KDLTransformException("cuddly_dicts can't handle tags")
        
        match node:
            # Simple property
            case kdl.Node(
                name=name,
                args=[value],
                props=OrderedDict(),
                nodes=[]
            ):
                if ret.get(name):
                    raise KDLTransformException(f"{name} already exists on {root_name}")
                
                ret[name] = value
            
            # Node with no args and some properties
            case kdl.Node(
                name=name,
                args=[],
                props=props,
                nodes=nodes
            ):
                if ret.get(name):
                    raise KDLTransformException(f"{name} already exists on {root_name}")
                
                ret[name] = {
                    **_nodes_to_dict(nodes, f"{root_name}.{name}"),
                    **props
                }
            
            # Node with args and properties
            case kdl.Node(
                name=name,
                args=[arg],
                props=props,
                nodes=nodes
            ):
                node_dict = ret.get(name, {})
                if not isinstance(node_dict, dict):
                    raise KDLTransformException(f"{name} already exists on {root_name} and isn't a dictionary")
                
                node_dict[arg] = {
                    **_nodes_to_dict(nodes, f"{root_name}.{name}.{arg}"),
                    **props
                }
                
                ret[name] = node_dict
            
            case _:
                raise KDLTransformException(f"node {node} didn't match any rules")
    
    return ret

def kdl_document_to_dict(document: kdl.Document) -> dict[str, Any]:
    return _nodes_to_dict(document.nodes, "")

def kdl_source_to_dict(source: str) -> dict[str, Any]:
    document = kdl.parse(source)
    return kdl_document_to_dict(document)
